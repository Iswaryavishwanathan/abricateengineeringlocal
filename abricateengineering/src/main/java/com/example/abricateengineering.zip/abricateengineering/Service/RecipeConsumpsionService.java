package com.example.abricateengineering.Service;

public class RecipeConsumpsionService {

}
